from flask import Flask
from extensions import db
from flask_wtf import CSRFProtect
import os

def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')

    app.config['UPLOAD_FOLDER'] = os.path.join('static', 'uploads')

    db.init_app(app)
    CSRFProtect(app)

    from routes.auth import auth_bp
    from routes.posts import posts_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(posts_bp)

    with app.app_context():
        from models import User, Post
        db.create_all()

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
