from flask import Blueprint, render_template, redirect, url_for, flash, request, session, current_app
from extensions import db
from models import Post
from forms import PostForm, EmptyForm
import os
from utils import allowed_file

posts_bp = Blueprint('posts', __name__)

@posts_bp.route('/')
def home():
    posts = Post.query.order_by(Post.date_posted.desc()).all()
    form = EmptyForm()
    return render_template('dashboard.html', posts=posts, form=form)

@posts_bp.route('/post/new', methods=['GET', 'POST'])
def new_post():
    if 'user_id' not in session:
        flash('Please login to create a post.', 'warning')
        return redirect(url_for('auth.login'))

    form = PostForm()
    if form.validate_on_submit():
        filename = None
        if form.image.data:
            if allowed_file(form.image.data.filename):
                filename = form.image.data.filename
                filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                form.image.data.save(filepath)
            else:
                flash('Invalid file type.', 'danger')
                return redirect(request.url)

        post = Post(
            title=form.title.data,
            content=form.content.data,
            image_filename=filename,
            user_id=session['user_id']
        )
        db.session.add(post)
        db.session.commit()
        flash('Your post has been created!', 'success')
        return redirect(url_for('posts.home'))

    return render_template('create_post.html', form=form)

@posts_bp.route('/post/<int:post_id>')
def post_detail(post_id):
    post = Post.query.get_or_404(post_id)
    return render_template('view_post.html', post=post)

@posts_bp.route('/post/<int:post_id>/delete', methods=['POST'])
def delete_post(post_id):
    post = Post.query.get_or_404(post_id)

    if post.user_id != session.get('user_id'):
        flash('You are not allowed to delete this post.', 'danger')
        return redirect(url_for('posts.home'))

    if post.image_filename:
        image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], post.image_filename)
        if os.path.exists(image_path):
            os.remove(image_path)

    db.session.delete(post)
    db.session.commit()
    flash('Post has been deleted!', 'success')
    return redirect(url_for('posts.home'))
